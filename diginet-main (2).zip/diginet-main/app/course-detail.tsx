import { IconSymbol } from "@/components/ui/IconSymbol";
import { useDeviceInfo } from "@/hooks/useDeviceInfo";
import { useLocalSearchParams, useRouter } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  Linking,
  ScrollView,
  StatusBar,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

export default function CourseDetailScreen() {
  const router = useRouter();
  const { courseId } = useLocalSearchParams();
  const { getTopPadding, getBottomPadding } = useDeviceInfo();
  const [currentQuizQuestion, setCurrentQuizQuestion] = useState(0);
  const [quizAnswers, setQuizAnswers] = useState<number[]>([]);
  const [showQuiz, setShowQuiz] = useState(false);

  const courses = [
    {
      id: 1,
      subject: "Informática Básica",
      title: "Fundamentos de Computación",
      description:
        "Este recurso proporciona una introducción completa a los conceptos básicos de computación, cubriendo hardware, software y habilidades digitales esenciales.",
      thumbnail: "💻",
      color: "#3B82F6",
      components: [
        {
          id: 1,
          title: "Vista General del Hardware",
          description: "Aprende sobre las partes físicas de una computadora.",
          icon: "desktopcomputer",
          screen: "hardware-overview",
        },
        {
          id: 2,
          title: "Conceptos Básicos de Software",
          description: "Entiende los diferentes tipos de software.",
          icon: "doc.text",
          screen: "software-basics",
        },
        {
          id: 3,
          title: "Video de Introducción",
          description: "Guía paso a paso en video.",
          icon: "play.circle",
          screen: "intro-video",
        },
        {
          id: 4,
          title: "Evaluación",
          description: "Pon a prueba tus conocimientos con un cuestionario.",
          icon: "checkmark.circle",
          screen: "quiz",
        },
      ],
      quiz: [
        {
          question: "¿Cuál es la función principal del CPU?",
          options: [
            "Almacenar datos permanentemente",
            "Procesar información y ejecutar programas",
            "Mostrar imágenes en la pantalla",
            "Conectar la computadora a internet",
          ],
          correct: 1,
        },
        {
          question: "¿Qué significa RAM?",
          options: [
            "Read Access Memory",
            "Random Access Memory",
            "Remote Access Memory",
            "Rapid Access Memory",
          ],
          correct: 1,
        },
        {
          question: "¿Cuál es la diferencia entre hardware y software?",
          options: [
            "No hay diferencia, son lo mismo",
            "Hardware son programas, software son partes físicas",
            "Hardware son partes físicas, software son programas",
            "Hardware es más caro que software",
          ],
          correct: 2,
        },
        {
          question:
            "¿Cuál es el sistema operativo más común en computadoras personales?",
          options: ["Linux", "Windows", "macOS", "Android"],
          correct: 1,
        },
        {
          question: "¿Qué tipo de computadora es más portátil?",
          options: [
            "Computadora de escritorio",
            "Laptop",
            "Servidor",
            "Mainframe",
          ],
          correct: 1,
        },
      ],
    },
    {
      id: 2,
      subject: "Internet y Navegación",
      title: "Navegación Segura en la Web",
      description:
        "Explora cómo usar internet de manera segura, identificar información confiable y proteger tu privacidad en línea.",
      thumbnail: "🌐",
      color: "#10B981",
      components: [
        {
          id: 1,
          title: "Conceptos de Internet",
          description: "Entiende cómo funciona internet.",
          icon: "network",
          screen: "internet-concepts",
        },
        {
          id: 2,
          title: "Navegadores Web",
          description: "Aprende a usar navegadores de forma efectiva.",
          icon: "globe",
          screen: "web-browsers",
        },
        {
          id: 3,
          title: "Seguridad en Línea",
          description: "Protege tu información personal.",
          icon: "lock.shield",
          screen: "online-security",
        },
        {
          id: 4,
          title: "Evaluación",
          description: "Pon a prueba tus conocimientos con un cuestionario.",
          icon: "checkmark.circle",
          screen: "quiz",
        },
      ],
      quiz: [
        {
          question: "¿Qué es HTTPS?",
          options: [
            "Un tipo de virus informático",
            "Un protocolo seguro para sitios web",
            "Un navegador web",
            "Una red social",
          ],
          correct: 1,
        },
        {
          question: "¿Cuál es la mejor práctica para contraseñas?",
          options: [
            "Usar la misma contraseña para todas las cuentas",
            "Usar información personal como fecha de nacimiento",
            "Usar contraseñas largas y complejas con letras, números y símbolos",
            "No usar contraseñas",
          ],
          correct: 2,
        },
        {
          question:
            "¿Qué debes verificar antes de ingresar información personal en un sitio web?",
          options: [
            "Que el sitio tenga muchos colores",
            "Que la URL comience con HTTPS y sea la correcta",
            "Que el sitio tenga muchas imágenes",
            "Que el sitio esté en inglés",
          ],
          correct: 1,
        },
        {
          question: "¿Qué es un navegador web?",
          options: [
            "Un programa antivirus",
            "Un programa para acceder a sitios web",
            "Un tipo de computadora",
            "Un dispositivo de almacenamiento",
          ],
          correct: 1,
        },
        {
          question: "¿Qué debes hacer si recibes un enlace sospechoso?",
          options: [
            "Hacer clic inmediatamente",
            "Compartirlo con todos tus amigos",
            "No hacer clic y verificar la fuente",
            "Descargar todo lo que contenga",
          ],
          correct: 2,
        },
      ],
    },
    {
      id: 3,
      subject: "Comunicación Digital",
      title: "Email y Mensajería",
      description:
        "Aprende a crear y gestionar cuentas de correo electrónico, enviar mensajes y usar aplicaciones de comunicación.",
      thumbnail: "📧",
      color: "#F59E0B",
      components: [
        {
          id: 1,
          title: "Conceptos de Email",
          description: "Entiende qué es el email y cómo funciona.",
          icon: "envelope",
          screen: "email-concepts",
        },
        {
          id: 2,
          title: "Aplicaciones de Mensajería",
          description: "Aprende sobre WhatsApp, Telegram y más.",
          icon: "message",
          screen: "messaging-apps",
        },
        {
          id: 3,
          title: "Netiqueta Digital",
          description: "Buenas prácticas para comunicarse en línea.",
          icon: "hand.raised",
          screen: "digital-etiquette",
        },
        {
          id: 4,
          title: "Evaluación",
          description: "Pon a prueba tus conocimientos con un cuestionario.",
          icon: "checkmark.circle",
          screen: "quiz",
        },
      ],
      quiz: [
        {
          question: "¿Qué significa 'email'?",
          options: [
            "Mensaje electrónico",
            "Correo electrónico",
            "Ambos son correctos",
            "Ninguno es correcto",
          ],
          correct: 2,
        },
        {
          question: "¿Cuál es la parte más importante de un email?",
          options: [
            "El color del texto",
            "La dirección del destinatario",
            "El tamaño de la letra",
            "El fondo del mensaje",
          ],
          correct: 1,
        },
        {
          question: "¿Qué significa escribir todo en MAYÚSCULAS en un mensaje?",
          options: [
            "Que es muy importante",
            "Que estás gritando o enojado",
            "Que es un título",
            "Que es más fácil de leer",
          ],
          correct: 1,
        },
        {
          question: "¿Cuál es la diferencia entre email y WhatsApp?",
          options: [
            "No hay diferencia",
            "Email es más formal, WhatsApp es más casual",
            "Email es más rápido",
            "WhatsApp es más caro",
          ],
          correct: 1,
        },
      ],
    },
    {
      id: 4,
      subject: "Herramientas Digitales",
      title: "Productividad en Línea",
      description:
        "Descubre herramientas digitales para crear documentos, hojas de cálculo y presentaciones básicas.",
      thumbnail: "📊",
      color: "#8B5CF6",
      components: [
        {
          id: 1,
          title: "Procesadores de Texto",
          description: "Aprende a usar Word y Google Docs.",
          icon: "doc.text",
          screen: "word-processors",
        },
        {
          id: 2,
          title: "Hojas de Cálculo",
          description: "Domina Excel y Google Sheets.",
          icon: "tablecells",
          screen: "spreadsheets",
        },
        {
          id: 3,
          title: "Presentaciones",
          description: "Crea presentaciones con PowerPoint y Slides.",
          icon: "rectangle.stack",
          screen: "presentations",
        },
        {
          id: 4,
          title: "Evaluación",
          description: "Pon a prueba tus conocimientos con un cuestionario.",
          icon: "checkmark.circle",
          screen: "quiz",
        },
      ],
      quiz: [
        {
          question: "¿Para qué se usa principalmente un procesador de texto?",
          options: [
            "Para hacer cálculos matemáticos",
            "Para crear documentos escritos",
            "Para crear presentaciones",
            "Para navegar en internet",
          ],
          correct: 1,
        },
        {
          question:
            "¿Qué herramienta es mejor para organizar datos en filas y columnas?",
          options: [
            "Procesador de texto",
            "Hoja de cálculo",
            "Presentación",
            "Navegador web",
          ],
          correct: 1,
        },
        {
          question: "¿Qué es la 'nube' en términos digitales?",
          options: [
            "Un tipo de computadora",
            "Almacenamiento en internet",
            "Un programa antivirus",
            "Un tipo de pantalla",
          ],
          correct: 1,
        },
        {
          question: "¿Cuál es la ventaja de usar herramientas en la nube?",
          options: [
            "Son más caras",
            "Solo funcionan en una computadora",
            "Puedes acceder desde cualquier dispositivo",
            "No necesitas internet",
          ],
          correct: 2,
        },
      ],
    },
    {
      id: 5,
      subject: "Redes Sociales",
      title: "Uso Responsable de Redes",
      description:
        "Aprende a usar las redes sociales de manera segura, crear contenido y conectar con otros de forma responsable.",
      thumbnail: "📱",
      color: "#EC4899",
      components: [
        {
          id: 1,
          title: "Conceptos de Redes Sociales",
          description: "Entiende qué son y cómo funcionan.",
          icon: "person.3",
          screen: "social-media-concepts",
        },
        {
          id: 2,
          title: "Configuración de Privacidad",
          description: "Protege tu información personal.",
          icon: "lock",
          screen: "privacy-settings",
        },
        {
          id: 3,
          title: "Contenido Responsable",
          description: "Buenas prácticas para publicar contenido.",
          icon: "hand.raised",
          screen: "responsible-content",
        },
        {
          id: 4,
          title: "Evaluación",
          description: "Pon a prueba tus conocimientos con un cuestionario.",
          icon: "checkmark.circle",
          screen: "quiz",
        },
      ],
      quiz: [
        {
          question:
            "¿Qué debes hacer antes de publicar algo en redes sociales?",
          options: [
            "Publicar inmediatamente",
            "Pensar en las consecuencias",
            "Copiar lo que otros publican",
            "No revisar nada",
          ],
          correct: 1,
        },
        {
          question: "¿Qué información NO debes compartir en redes sociales?",
          options: [
            "Tu nombre completo",
            "Tu dirección y número de teléfono",
            "Una foto de tu comida",
            "Un comentario sobre el clima",
          ],
          correct: 1,
        },
        {
          question: "¿Qué es el ciberacoso?",
          options: [
            "Usar internet para aprender",
            "Usar tecnología para molestar o amenazar",
            "Hacer amigos en línea",
            "Compartir fotos con familia",
          ],
          correct: 1,
        },
        {
          question: "¿Qué debes hacer si alguien te acosa en línea?",
          options: [
            "Responder con insultos",
            "Ignorar y reportar el comportamiento",
            "Compartir la información con todos",
            "Eliminar tu cuenta inmediatamente",
          ],
          correct: 1,
        },
      ],
    },
    {
      id: 6,
      subject: "Seguridad Digital",
      title: "Protección en Línea",
      description:
        "Conoce las mejores prácticas para proteger tu información personal y evitar estafas en internet.",
      thumbnail: "🔒",
      color: "#EF4444",
      components: [
        {
          id: 1,
          title: "Amenazas Digitales",
          description: "Conoce virus, malware y phishing.",
          icon: "exclamationmark.triangle",
          screen: "digital-threats",
        },
        {
          id: 2,
          title: "Contraseñas Seguras",
          description: "Aprende a crear contraseñas fuertes.",
          icon: "key",
          screen: "secure-passwords",
        },
        {
          id: 3,
          title: "Autenticación de Dos Factores",
          description: "Añade una capa extra de seguridad.",
          icon: "lock.shield",
          screen: "two-factor-auth",
        },
        {
          id: 4,
          title: "Evaluación",
          description: "Pon a prueba tus conocimientos con un cuestionario.",
          icon: "checkmark.circle",
          screen: "quiz",
        },
      ],
      quiz: [
        {
          question: "¿Qué es el phishing?",
          options: [
            "Un tipo de pesca",
            "Un intento de engaño para obtener información personal",
            "Un programa antivirus",
            "Un tipo de red social",
          ],
          correct: 1,
        },
        {
          question: "¿Cuál es una característica de una contraseña segura?",
          options: [
            "Usar solo letras",
            "Usar tu nombre",
            "Usar al menos 8 caracteres con letras, números y símbolos",
            "Usar la misma para todas las cuentas",
          ],
          correct: 2,
        },
        {
          question: "¿Por qué es importante mantener el software actualizado?",
          options: [
            "Porque es más bonito",
            "Porque arregla vulnerabilidades de seguridad",
            "Porque consume menos batería",
            "Porque es más rápido",
          ],
          correct: 1,
        },
        {
          question: "¿Qué es la autenticación de dos factores?",
          options: [
            "Usar dos contraseñas",
            "Una capa extra de seguridad con código adicional",
            "Tener dos cuentas",
            "Usar dos dispositivos",
          ],
          correct: 1,
        },
        {
          question: "¿Qué debes hacer si recibes un email sospechoso?",
          options: [
            "Hacer clic en todos los enlaces",
            "Responder inmediatamente",
            "No abrirlo y eliminarlo",
            "Reenviarlo a todos tus contactos",
          ],
          correct: 2,
        },
      ],
    },
  ];

  const course =
    courses.find((c) => c.id === parseInt(courseId as string)) || courses[0];

  const downloadPDF = () => {
    Alert.alert(
      "Descargar PDF",
      "¿Deseas descargar el material de este curso?",
      [
        {
          text: "Cancelar",
          style: "cancel",
        },
        {
          text: "Descargar",
          onPress: () => {
            // Here you would implement actual PDF download
            Alert.alert("Éxito", "El PDF se está descargando...");
          },
        },
      ]
    );
  };

  const handleQuizAnswer = (answerIndex: number) => {
    const newAnswers = [...quizAnswers];
    newAnswers[currentQuizQuestion] = answerIndex;
    setQuizAnswers(newAnswers);

    if (currentQuizQuestion < course.quiz.length - 1) {
      setCurrentQuizQuestion(currentQuizQuestion + 1);
    } else {
      // Quiz completed
      const correctAnswers = newAnswers.filter(
        (answer, index) => answer === course.quiz[index].correct
      ).length;

      Alert.alert(
        "¡Cuestionario Completado!",
        `Obtuviste ${correctAnswers} de ${course.quiz.length} respuestas correctas.`,
        [
          {
            text: "OK",
            onPress: () => {
              setShowQuiz(false);
              setCurrentQuizQuestion(0);
              setQuizAnswers([]);
            },
          },
        ]
      );
    }
  };

  const renderQuiz = () => {
    if (!showQuiz) return null;

    const question = course.quiz[currentQuizQuestion];

    return (
      <View className="bg-white rounded-xl p-6 mb-4 border border-gray-100">
        <Text className="text-lg font-bold text-gray-800 mb-4">
          Pregunta {currentQuizQuestion + 1} de {course.quiz.length}
        </Text>
        <Text className="text-base text-gray-700 mb-6">
          {question.question}
        </Text>
        {question.options.map((option, index) => (
          <TouchableOpacity
            key={index}
            className={`p-4 rounded-lg mb-3 border ${
              quizAnswers[currentQuizQuestion] === index
                ? "bg-blue-50 border-blue-300"
                : "bg-gray-50 border-gray-200"
            }`}
            onPress={() => handleQuizAnswer(index)}
          >
            <Text className="text-base text-gray-800">
              {String.fromCharCode(65 + index)}. {option}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    );
  };

  const handleComponentPress = (component: any) => {
    if (component.screen === "quiz") {
      setShowQuiz(true);
    } else {
      router.push({
        pathname: "/concept-detail" as any,
        params: {
          courseId: courseId as string,
          conceptScreen: component.screen,
          conceptTitle: component.title,
        },
      });
    }
  };

  return (
    <>
      <StatusBar barStyle="dark-content" hidden={true} />
      <View
        className="flex-1 bg-gray-50"
        style={{
          paddingTop: getTopPadding(),
          paddingBottom: getBottomPadding(),
        }}
      >
        {/* Header */}
        <View className="flex-row items-center px-6 mb-6">
          <TouchableOpacity className="mr-4" onPress={() => router.back()}>
            <IconSymbol name="chevron.left" size={24} color="#000" />
          </TouchableOpacity>
          <Text className="text-xl font-bold text-black">
            Detalles del Recurso
          </Text>
        </View>

        <ScrollView
          className="flex-1 px-6"
          showsVerticalScrollIndicator={false}
        >
          {/* Course Title and Description */}
          <View className="mb-6">
            <Text className="text-2xl font-bold text-gray-800 mb-3">
              {course.title}
            </Text>
            <Text className="text-base text-gray-600 leading-6">
              {course.description}
            </Text>
          </View>

          {/* Quiz Section */}
          {renderQuiz()}

          {/* Components Section */}
          <View className="mb-6">
            <Text className="text-lg font-bold text-gray-800 mb-4">
              Componentes
            </Text>

            {course.components?.map((component) => (
              <TouchableOpacity
                key={component.id}
                className="bg-white rounded-xl p-4 mb-3 border border-gray-100"
                onPress={() => handleComponentPress(component)}
              >
                <View className="flex-row items-center">
                  <View className="w-12 h-12 rounded-full bg-blue-100 items-center justify-center mr-4">
                    <IconSymbol
                      name={component.icon as any}
                      size={24}
                      color="#3B82F6"
                    />
                  </View>
                  <View className="flex-1">
                    <Text className="text-base font-bold text-gray-800 mb-1">
                      {component.title}
                    </Text>
                    <Text className="text-sm text-gray-600">
                      {component.description}
                    </Text>
                  </View>
                </View>
              </TouchableOpacity>
            ))}
          </View>

          {/* Download PDF Section */}
          <View className="mb-8">
            <TouchableOpacity
              className="bg-blue-500 rounded-xl p-4 flex-row items-center justify-center"
              onPress={downloadPDF}
            >
              <IconSymbol
                name="arrow.down.circle.fill"
                size={24}
                color="white"
              />
              <Text className="text-white font-semibold text-base ml-2">
                Descargar Material PDF
              </Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>
    </>
  );
}
