import {
  Avatar,
  AvatarFallbackText,
  AvatarImage,
} from "@/components/ui/avatar";
import { IconSymbol } from "@/components/ui/IconSymbol";
import { useAuth } from "@/hooks/useAuth";
import { useDeviceInfo } from "@/hooks/useDeviceInfo";
import { useRouter } from "expo-router";
import React from "react";
import {
  Alert,
  ScrollView,
  StatusBar,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

export default function ProfileScreen() {
  const { user, logout } = useAuth();
  const { getTopPadding, getBottomPadding } = useDeviceInfo();
  const router = useRouter();

  const progressData = [
    { subject: "Informática Básica", progress: 25, color: "#3B82F6" },
    { subject: "Tecnología y Sociedad", progress: 50, color: "#10B981" },
    { subject: "Herramientas Digitales", progress: 75, color: "#F59E0B" },
  ];

  const handleLogout = () => {
    Alert.alert(
      "Cerrar Sesión",
      "¿Estás seguro de que quieres cerrar sesión?",
      [
        {
          text: "Cancelar",
          style: "cancel",
        },
        {
          text: "Cerrar Sesión",
          style: "destructive",
          onPress: () => {
            logout();
            router.replace("/(auth)/landing");
          },
        },
      ]
    );
  };

  return (
    <>
      <StatusBar barStyle="dark-content" />
      <View
        className="flex-1 bg-white"
        style={{
          paddingTop: getTopPadding(),
          paddingBottom: getBottomPadding(),
        }}
      >
        {/* Header */}
        <View className="flex-row items-center justify-between px-6 mb-6">
          <View style={{ width: 24 }} />
          <Text className="text-xl font-bold text-black">Perfil</Text>
          <TouchableOpacity>
            <IconSymbol name="bell" size={24} color="#000" />
          </TouchableOpacity>
        </View>

        <ScrollView
          className="flex-1 px-6"
          showsVerticalScrollIndicator={false}
        >
          {/* Profile Picture and Info */}
          <View className="items-center mb-8">
            <Avatar
              className="bg-gray-300 items-center justify-center mb-4"
              size="xl"
            >
              <AvatarImage src="https://github.com/shadcn.png" />
              <AvatarFallbackText className="text-black text-2xl">
                Sebas Campos
              </AvatarFallbackText>
            </Avatar>
            <Text className="text-2xl font-bold text-black mb-1">
              {user?.name || "Sebas Campos"}
            </Text>
            <Text className="text-base text-gray-500">
              {user?.email || "2020207@est.cedesdonbosco.ed.cr"}
            </Text>
          </View>

          {/* Account Section */}
          <View className="mb-8">
            <Text className="text-lg font-bold text-black mb-4">Cuenta</Text>
            <View className="bg-white rounded-xl border border-gray-200 overflow-hidden">
              <TouchableOpacity className="flex-row items-center justify-between p-4 border-b border-gray-100">
                <Text className="text-base text-black">Editar Perfil</Text>
                <IconSymbol name="chevron.right" size={20} color="#9CA3AF" />
              </TouchableOpacity>
            </View>
          </View>

          {/* Progress Section */}
          <View className="mb-8">
            <Text className="text-lg font-bold text-black mb-4">Progreso</Text>
            <View className="bg-white rounded-xl border border-gray-200 p-4">
              {progressData.map((item, index) => (
                <View key={index} className="mb-4 last:mb-0 mt-5">
                  <View className="flex-row items-center justify-between mb-2">
                    <Text className="text-base text-black font-medium">
                      {item.subject}
                    </Text>
                    <Text
                      className="text-base font-medium"
                      style={{ color: item.color }}
                    >
                      {item.progress}%
                    </Text>
                  </View>
                  <View className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <View
                      className="h-full rounded-full"
                      style={{
                        width: `${item.progress}%`,
                        backgroundColor: item.color,
                      }}
                    />
                  </View>
                </View>
              ))}
            </View>
          </View>

          {/* Additional Options */}
          <View className="mb-8">
            <View className="bg-white rounded-xl border border-gray-200 overflow-hidden">
              <TouchableOpacity className="flex-row items-center justify-between p-4 border-b border-gray-100">
                <Text className="text-base text-black">Configuración</Text>
                <IconSymbol name="chevron.right" size={20} color="#9CA3AF" />
              </TouchableOpacity>
              <TouchableOpacity className="flex-row items-center justify-between p-4 border-b border-gray-100">
                <Text className="text-base text-black">Ayuda y Soporte</Text>
                <IconSymbol name="chevron.right" size={20} color="#9CA3AF" />
              </TouchableOpacity>
              <TouchableOpacity
                className="flex-row items-center justify-between p-4"
                onPress={handleLogout}
              >
                <Text className="text-base text-red-500">Cerrar Sesión</Text>
                <IconSymbol name="chevron.right" size={20} color="#EF4444" />
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </View>
    </>
  );
}
