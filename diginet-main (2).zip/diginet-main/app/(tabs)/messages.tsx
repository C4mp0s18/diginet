import {
  Avatar,
  AvatarFallbackText,
  AvatarImage,
} from "@/components/ui/avatar";
import { IconSymbol } from "@/components/ui/IconSymbol";
import { useDeviceInfo } from "@/hooks/useDeviceInfo";
import React from "react";
import {
  ScrollView,
  StatusBar,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

export default function MessagesScreen() {
  const { getTopPadding, getBottomPadding } = useDeviceInfo();

  const messages = [
    {
      id: 1,
      name: "Fabian Rivera",
      lastMessage: "¡Nos vemos mañana!",
      time: "2m",
      isOnline: true,
      avatar: "👩‍🏫",
    },
    {
      id: 2,
      name: "Juan Perez",
      lastMessage: "Estoy aquí para ayudarte",
      time: "1h",
      isOnline: false,
      avatar: "👨‍💻",
    },
    {
      id: 3,
      name: "Maria Lopez",
      lastMessage: "Gracias por compartir ese material",
      time: "Ayer",
      isOnline: true,
      avatar: "👨‍🎓",
    },
    {
      id: 4,
      name: "Pedro Garcia",
      lastMessage: "Estoy aquí para ayudar",
      time: "2d",
      isOnline: false,
      avatar: "👩‍🎨",
    },
  ];

  return (
    <>
      <StatusBar barStyle="dark-content" />
      <View
        className="flex-1 bg-white"
        style={{
          paddingTop: getTopPadding(),
          paddingBottom: getBottomPadding(),
        }}
      >
        {/* Header */}
        <View className="flex-row items-center justify-between px-6 mb-6">
          <Text className="text-xl font-bold text-black">Mensajes</Text>
          <View style={{ width: 24 }} />
        </View>

        <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
          {/* Messages List */}
          {messages.map((message) => (
            <TouchableOpacity
              key={message.id}
              className="bg-white p-6 border border-gray-100"
              onPress={() => {
                // Handle message press
                console.log(`Pressed: ${message.name}`);
              }}
            >
              <View className="flex-row items-center">
                {/* Avatar */}
                <View className="relative">
                  <Avatar
                    className="bg-gray-200 items-center justify-center mr-4"
                    size="lg"
                  >
                    <AvatarImage src="https://github.com/shadcn.png" />
                    <AvatarFallbackText className="text-black text-2xl">
                      {message.name}
                    </AvatarFallbackText>
                  </Avatar>
                  {/* Online/Offline indicator */}
                  <View
                    className={`absolute bottom-0 right-3 w-3 h-3 rounded-full border-2 border-white ${
                      message.isOnline ? "bg-green-500" : "bg-red-500"
                    }`}
                  />
                </View>

                {/* Message Content */}
                <View className="flex-1">
                  <Text className="text-base font-bold text-black mb-1">
                    {message.name}
                  </Text>
                  <Text className="text-sm text-gray-600">
                    {message.lastMessage}
                  </Text>
                </View>

                {/* Time */}
                <Text className="text-xs text-gray-500">{message.time}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Floating Action Button */}
        <TouchableOpacity
          className="absolute bottom-16 right-10 bg-blue-500 w-14 h-14 rounded-full items-center justify-center shadow-sm"
          onPress={() => {
            // Handle new message
            console.log("New message pressed");
          }}
        >
          <IconSymbol name="paperplane.fill" size={24} color="#fff" />
        </TouchableOpacity>
      </View>
    </>
  );
}
