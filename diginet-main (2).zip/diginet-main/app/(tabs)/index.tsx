import { IconSymbol } from "@/components/ui/IconSymbol";
import { useAuth } from "@/hooks/useAuth";
import { useDeviceInfo } from "@/hooks/useDeviceInfo";
import { useRouter } from "expo-router";
import React, { useState, useEffect, useRef } from "react";
import {
  ScrollView,
  StatusBar,
  Text,
  TouchableOpacity,
  View,
  Dimensions,
  FlatList,
} from "react-native";

const { width: screenWidth } = Dimensions.get("window");

export default function HomeScreen() {
  const router = useRouter();
  const { user } = useAuth();
  const { getTopPadding, getBottomPadding } = useDeviceInfo();
  const [currentFactIndex, setCurrentFactIndex] = useState(0);
  const flatListRef = useRef<FlatList>(null);
  const [completedTasks, setCompletedTasks] = useState<number[]>([]);

  const digitalFacts = [
    {
      id: 1,
      fact: "El 90% de los trabajos requieren habilidades digitales básicas",
      category: "Empleo",
      icon: "💼",
      color: "#E3F2FD",
    },
    {
      id: 2,
      fact: "Más de 4.5 mil millones de personas usan internet en el mundo",
      category: "Conectividad",
      icon: "🌐",
      color: "#E8F5E8",
    },
    {
      id: 3,
      fact: "Aprender a programar puede aumentar tu salario hasta un 30%",
      category: "Desarrollo",
      icon: "💻",
      color: "#FFF3E0",
    },
    {
      id: 4,
      fact: "El 70% de las empresas buscan personas con habilidades digitales",
      category: "Mercado Laboral",
      icon: "📈",
      color: "#F3E5F5",
    },
    {
      id: 5,
      fact: "La alfabetización digital es esencial para la participación ciudadana",
      category: "Ciudadanía",
      icon: "🏛️",
      color: "#FCE4EC",
    },
  ];

  // Auto-scroll functionality
  useEffect(() => {
    const interval = setInterval(() => {
      const nextIndex = (currentFactIndex + 1) % digitalFacts.length;
      setCurrentFactIndex(nextIndex);
      flatListRef.current?.scrollToIndex({
        index: nextIndex,
        animated: true,
      });
    }, 4000); // Change fact every 4 seconds

    return () => clearInterval(interval);
  }, [currentFactIndex, digitalFacts.length]);

  const dailyTasks = [
    {
      id: 1,
      title: "Investigar una nueva tecnología",
      icon: "book.fill",
      reward: "10 pts",
    },
    {
      id: 2,
      title: "Leer un libro de tecnología",
      icon: "laptopcomputer",
      reward: "15 pts",
    },
    {
      id: 3,
      title: "Ayudar a alguien con tecnología",
      icon: "heart.fill",
      reward: "20 pts",
    },
    {
      id: 4,
      title: "Completar un ejercicio de alfabetización",
      icon: "pencil",
      reward: "12 pts",
    },
  ];

  const toggleTask = (taskId: number) => {
    setCompletedTasks((prev) =>
      prev.includes(taskId)
        ? prev.filter((id) => id !== taskId)
        : [...prev, taskId]
    );
  };

  const renderFactItem = ({ item, index }: { item: any; index: number }) => (
    <View
      className="bg-white rounded-2xl p-6 mx-2 border border-gray-100"
      style={{ width: screenWidth - 48 }}
    >
      <View className="flex-row items-center mb-4">
        <Text className="text-4xl mr-4">{item.icon}</Text>
        <View className="flex-1">
          <Text className="text-xs text-blue-600 font-semibold uppercase tracking-wide">
            {item.category}
          </Text>
        </View>
      </View>
      <Text className="text-gray-800 text-base leading-6 font-medium">
        "{item.fact}"
      </Text>
    </View>
  );

  const renderTaskItem = (task: any) => {
    const isCompleted = completedTasks.includes(task.id);

    return (
      <TouchableOpacity
        className={`rounded-xl p-4 mb-3 border ${
          isCompleted
            ? "bg-green-50 border-green-200"
            : "bg-white border-gray-100"
        }`}
        onPress={() => toggleTask(task.id)}
      >
        <View className="flex-row items-center">
          <View
            className={`w-10 h-10 rounded-full items-center justify-center mr-3 ${
              isCompleted ? "bg-green-100" : "bg-blue-100"
            }`}
          >
            <IconSymbol
              name={task.icon as any}
              size={20}
              color={isCompleted ? "#10B981" : "#3B82F6"}
            />
          </View>
          <View className="flex-1">
            <Text
              className={`font-semibold text-sm ${
                isCompleted ? "text-green-800 line-through" : "text-black"
              }`}
            >
              {task.title}
            </Text>
          </View>
          <View className="flex-row items-center">
            <Text
              className={`text-xs font-bold mr-3 ${
                isCompleted ? "text-green-600" : "text-gray-500"
              }`}
            >
              {task.reward}
            </Text>
            <View
              className={`w-6 h-6 rounded-full border-2 items-center justify-center ${
                isCompleted
                  ? "bg-green-500 border-green-500"
                  : "border-gray-300"
              }`}
            >
              {isCompleted && (
                <IconSymbol name="checkmark" size={12} color="white" />
              )}
            </View>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <>
      <StatusBar barStyle="dark-content" />
      <View
        className="flex-1 bg-gray-50"
        style={{
          paddingTop: getTopPadding(),
          paddingBottom: getBottomPadding(),
        }}
      >
        {/* Header */}
        <View className="flex-row items-center justify-between px-6 mb-6">
          <TouchableOpacity>
            <IconSymbol name="menu" size={24} color="#000" />
          </TouchableOpacity>
          <Text className="text-xl font-bold text-black">Inicio</Text>
          <TouchableOpacity>
            <IconSymbol name="bell" size={24} color="#000" />
          </TouchableOpacity>
        </View>

        <ScrollView
          className="flex-1 px-6"
          showsVerticalScrollIndicator={false}
        >
          {/* Welcome Section */}
          <View className="mb-6">
            <Text className="text-2xl font-bold text-black mb-2">
              ¡Bienvenido, {user?.name || "Sebas"}!
            </Text>
            <Text className="text-base text-gray-600">
              Continúa tu camino de aprendizaje y descubre nuevos desafíos.
            </Text>
          </View>

          {/* Digital Facts Carousel */}
          <View className="mb-8">
            <FlatList
              ref={flatListRef}
              data={digitalFacts}
              renderItem={renderFactItem}
              keyExtractor={(item) => item.id.toString()}
              horizontal
              showsHorizontalScrollIndicator={false}
              pagingEnabled
              onMomentumScrollEnd={(event) => {
                const index = Math.round(
                  event.nativeEvent.contentOffset.x / (screenWidth - 32)
                );
                setCurrentFactIndex(index);
              }}
              snapToInterval={screenWidth - 32}
              decelerationRate="fast"
            />

            {/* Pagination Dots */}
            <View className="flex-row justify-center mt-4">
              {digitalFacts.map((_, index) => (
                <View
                  key={index}
                  className={`w-2 h-2 rounded-full mx-1 ${
                    index === currentFactIndex ? "bg-blue-500" : "bg-gray-300"
                  }`}
                />
              ))}
            </View>
          </View>

          {/* Daily Tasks */}
          <View className="mb-6">
            <View className="flex-row items-center justify-between mb-4">
              <Text className="text-lg font-bold text-black">
                Tareas de Hoy
              </Text>
              <Text className="text-sm text-gray-500">
                {completedTasks.length}/{dailyTasks.length} completadas
              </Text>
            </View>
            {dailyTasks.map((task) => (
              <View key={task.id}>{renderTaskItem(task)}</View>
            ))}
          </View>
        </ScrollView>
      </View>
    </>
  );
}
