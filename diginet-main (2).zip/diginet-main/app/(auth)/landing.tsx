import { Button, ButtonText } from "@/components/ui/button";
import { IconSymbol } from "@/components/ui/IconSymbol";
import { useRouter } from "expo-router";
import React from "react";
import { Text, View } from "react-native";

export default function LandingScreen() {
  const router = useRouter();

  return (
    <>
      {/* <Stack.Screen options={{ title: "Welcome" }} /> */}
      <View className="flex-1 flex-col items-center justify-center ">
        {/* Icon above the welcome text */}
        <IconSymbol
          name="graduationcap.fill"
          size={80}
          color="#3B82F6"
          style={{ marginBottom: 24 }}
        />

        <Text className="text-5xl mb-8 font-bold text-center">
          ¡Bienvenido a Diginet!
        </Text>
        <Text className="text-xl mb-8 text-center text-gray-500 mx-4">
          Tu viaje al conocimiento comienza aquí.
        </Text>
        <View className="w-[75%]">
          <Button
            variant="solid"
            className="w-full bg-blue-500 rounded-full h-14"
            onPress={() => router.push("/(auth)/signup")}
          >
            <ButtonText className="text-white font-bold text-xl">
              Crear cuenta
            </ButtonText>
          </Button>

          <View style={{ height: 16 }} />
          <Button
            variant="solid"
            action="secondary"
            className="w-full rounded-full h-14"
            onPress={() => router.push("/(auth)/login")}
          >
            <ButtonText className="font-bold text-xl text-slate-800">
              Iniciar sesión
            </ButtonText>
          </Button>
        </View>
      </View>
    </>
  );
}
