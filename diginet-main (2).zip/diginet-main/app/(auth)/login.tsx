import { Button, ButtonText } from "@/components/ui/button";
import { IconSymbol } from "@/components/ui/IconSymbol";
import { useAuth } from "@/hooks/useAuth";
import { useDeviceInfo } from "@/hooks/useDeviceInfo";
import { Stack, useRouter } from "expo-router";
import React, { useState } from "react";
import { StatusBar, Text, TouchableOpacity, View } from "react-native";
import { Input, InputField } from "@/components/ui/input";

export default function LoginScreen() {
  const router = useRouter();
  const { login, isLoading } = useAuth();
  const { getTopPadding, getBottomPadding } = useDeviceInfo();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      // You could add proper validation here
      return;
    }

    try {
      await login();
      router.replace("/(tabs)");
    } catch (error) {
      console.error("Login failed:", error);
    }
  };

  return (
    <>
      <Stack.Screen
        options={{
          title: "Iniciar sesión",
          headerShown: false,
          animation: "ios_from_right",
        }}
      />
      <StatusBar barStyle="dark-content" />

      <View
        className="flex-1 bg-white"
        style={{
          paddingTop: getTopPadding(),
          paddingBottom: getBottomPadding(),
          paddingHorizontal: 24,
        }}
      >
        {/* Back Button */}
        <View className="flex-row items-center mb-8">
          <TouchableOpacity onPress={() => router.navigate("/(auth)/landing")}>
            <IconSymbol
              name="chevron.right"
              size={24}
              color="#000"
              style={{ transform: [{ rotate: "180deg" }] }}
            />
          </TouchableOpacity>
        </View>

        {/* Header */}
        <View className="mb-8">
          <Text className="text-3xl font-bold text-black mb-2">
            Bienvenido de nuevo
          </Text>
          <Text className="text-base text-gray-500">
            Inicia sesión para continuar tu viaje de aprendizaje.
          </Text>
        </View>

        {/* Form Fields */}
        <View className="flex-1">
          {/* Email Field */}
          <View className="mb-6">
            <Text className="text-base font-medium text-black mb-2">
              Correo electrónico
            </Text>
            {/* <View className="bg-gray-100 rounded-xl p-4"> */}
            <Input
              className="text-base text-black bg-gray-100 rounded-xl border-transparent h-14"
              variant="rounded"
              size="lg"
            >
              <InputField
                placeholder="tu@correo.com"
                placeholderTextColor="#9CA3AF"
                autoCapitalize="none"
                value={email}
                onChangeText={setEmail}
              />
            </Input>
            {/* </View> */}
          </View>

          {/* Password Field */}
          <View className="mb-8">
            <Text className="text-base font-medium text-black mb-2">
              Contraseña
            </Text>
            {/* <View className="bg-gray-100 rounded-xl p-4"> */}
            <Input
              className="text-base text-black bg-gray-100 rounded-xl border-transparent h-14"
              variant="rounded"
              size="lg"
            >
              <InputField
                placeholder="Ingresa tu contraseña"
                placeholderTextColor="#9CA3AF"
                value={password}
                onChangeText={setPassword}
                secureTextEntry
                type="password"
                autoComplete="password"
              />
            </Input>
            {/* </View> */}
          </View>

          {/* Sign In Button */}
          <Button
            variant="solid"
            className="w-full bg-blue-500 rounded-xl h-14 mb-6"
            onPress={handleLogin}
            disabled={isLoading || !email.trim() || !password.trim()}
          >
            <ButtonText className="text-white font-bold text-lg">
              {isLoading ? "Iniciando sesión..." : "Iniciar sesión"}
            </ButtonText>
          </Button>

          {/* Footer Link */}
          <View className="flex-row justify-center">
            <Text className="text-base text-gray-500">
              No tienes una cuenta?{" "}
            </Text>
            <Text
              className="text-base text-blue-500 font-medium"
              onPress={() => router.push("/(auth)/signup")}
            >
              Crear cuenta
            </Text>
          </View>
        </View>
      </View>
    </>
  );
}
