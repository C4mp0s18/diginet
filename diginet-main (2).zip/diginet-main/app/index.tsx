import { useAuth } from "@/hooks/useAuth";
import { useRouter } from "expo-router";
import { useEffect } from "react";

export default function Index() {
  const router = useRouter();
  const { isAuthenticated, isLoading } = useAuth();

  useEffect(() => {
    if (!isLoading) {
      if (isAuthenticated) {
        // If user is authenticated, redirect to the main app (tabs)
        router.replace("/(tabs)");
      } else {
        // If user is not authenticated, redirect to the landing screen
        router.replace("/(auth)/landing");
      }
    }
  }, [isAuthenticated, isLoading, router]);

  // Show loading state while checking authentication
  if (isLoading) {
    return null; // You could show a loading spinner here
  }

  // This component doesn't render anything as it immediately redirects
  return null;
}
