import { IconSymbol } from "@/components/ui/IconSymbol";
import { useDeviceInfo } from "@/hooks/useDeviceInfo";
import { useLocalSearchParams, useRouter } from "expo-router";
import React, { useState } from "react";
import {
  ScrollView,
  StatusBar,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

export default function ConceptDetailScreen() {
  const router = useRouter();
  const { courseId, conceptScreen, conceptTitle } = useLocalSearchParams();
  const { getTopPadding, getBottomPadding } = useDeviceInfo();
  const [expandedConcept, setExpandedConcept] = useState<number | null>(null);

  const conceptData = {
    "hardware-overview": {
      title: "Vista General del Hardware",
      description:
        "Aprende sobre las partes físicas de una computadora y cómo funcionan juntas.",
      concepts: [
        {
          id: 1,
          title: "¿Qué es una Computadora?",
          content:
            "Una computadora es una máquina electrónica que procesa información. Puede realizar cálculos, almacenar datos y ejecutar programas. Las computadoras modernas tienen cuatro componentes principales: CPU, memoria, almacenamiento y dispositivos de entrada/salida.",
          icon: "desktopcomputer",
        },
        {
          id: 2,
          title: "CPU (Procesador)",
          content:
            "El CPU es el 'cerebro' de la computadora. Procesa todas las instrucciones y cálculos. Es el componente más importante que determina qué tan rápida es tu computadora. Los fabricantes más conocidos son Intel y AMD.",
          icon: "cpu",
        },
        {
          id: 3,
          title: "Memoria RAM",
          content:
            "La RAM es la memoria temporal que usa la computadora mientras está funcionando. Cuanta más RAM tengas, más programas podrás usar al mismo tiempo sin que la computadora se vuelva lenta.",
          icon: "memorychip",
        },
        {
          id: 4,
          title: "Disco Duro",
          content:
            "El disco duro almacena todos tus archivos, programas y el sistema operativo de forma permanente. Es como un armario gigante donde guardas todo. Los discos duros modernos pueden almacenar terabytes de información.",
          icon: "externaldrive",
        },
        {
          id: 5,
          title: "Dispositivos de Entrada/Salida",
          content:
            "• Teclado: Para escribir texto\n• Mouse: Para navegar y hacer clic\n• Monitor: Para ver la información\n• Impresora: Para imprimir documentos\n• Altavoces: Para escuchar sonido",
          icon: "keyboard",
        },
      ],
    },
    "software-basics": {
      title: "Conceptos Básicos de Software",
      description:
        "Entiende los diferentes tipos de software y cómo funcionan en tu computadora.",
      concepts: [
        {
          id: 1,
          title: "¿Qué es el Software?",
          content:
            "El software son los programas e instrucciones que le dicen al hardware qué hacer. Sin software, la computadora sería solo un conjunto de piezas sin función. Es como el 'pensamiento' de la computadora.",
          icon: "doc.text",
        },
        {
          id: 2,
          title: "Sistema Operativo",
          content:
            "El sistema operativo es el software principal que controla toda la computadora. Los más comunes son Windows, macOS y Linux. Es como el 'director' que coordina todos los programas y hardware.",
          icon: "gear",
        },
        {
          id: 3,
          title: "Software de Aplicación",
          content:
            "Son programas específicos para tareas particulares:\n• Word: Para escribir documentos\n• Excel: Para hojas de cálculo\n• Photoshop: Para editar imágenes\n• Navegadores: Para internet",
          icon: "app.badge",
        },
        {
          id: 4,
          title: "Software Libre vs Propietario",
          content:
            "Software Libre: Puedes usarlo, modificarlo y compartirlo gratis (ej: Linux, Firefox)\nSoftware Propietario: Tienes que pagar por usarlo y no puedes modificarlo (ej: Windows, Office)",
          icon: "lock.open",
        },
      ],
    },
    "internet-concepts": {
      title: "Conceptos de Internet",
      description:
        "Entiende cómo funciona internet y los conceptos básicos de conectividad.",
      concepts: [
        {
          id: 1,
          title: "¿Qué es Internet?",
          content:
            "Internet es una red global de computadoras conectadas que permite compartir información. Es como una 'autopista de información' que conecta millones de dispositivos en todo el mundo. Permite enviar emails, ver videos, buscar información y mucho más.",
          icon: "network",
        },
        {
          id: 2,
          title: "Cómo Funciona Internet",
          content:
            "Internet funciona enviando información en pequeños paquetes de datos. Estos paquetes viajan a través de cables, satélites y antenas hasta llegar a su destino. Es como enviar una carta por correo, pero mucho más rápido.",
          icon: "arrow.triangle.2.circlepath",
        },
        {
          id: 3,
          title: "Tipos de Conexión",
          content:
            "• WiFi: Conexión inalámbrica en casa o lugares públicos\n• Datos móviles: Conexión a través del teléfono celular\n• Cable: Conexión física por cable de internet\n• Fibra óptica: Conexión muy rápida por cables especiales",
          icon: "wifi",
        },
        {
          id: 4,
          title: "Direcciones IP",
          content:
            "Cada dispositivo en internet tiene una dirección única llamada IP (Protocolo de Internet). Es como la dirección de una casa, pero para computadoras. Permite que los dispositivos se encuentren y comuniquen entre sí.",
          icon: "number",
        },
      ],
    },
    "web-browsers": {
      title: "Navegadores Web",
      description: "Aprende a usar navegadores web de forma efectiva y segura.",
      concepts: [
        {
          id: 1,
          title: "¿Qué es un Navegador?",
          content:
            "Un navegador web es un programa que te permite acceder a sitios web. Es como una 'ventana' que te permite ver páginas web en internet. Los más populares son Chrome, Firefox, Safari y Edge.",
          icon: "globe",
        },
        {
          id: 2,
          title: "Partes del Navegador",
          content:
            "• Barra de direcciones: Donde escribes las URLs\n• Botones de navegación: Atrás, adelante, recargar\n• Pestañas: Para abrir múltiples páginas\n• Marcadores: Para guardar páginas favoritas\n• Historial: Para ver páginas visitadas",
          icon: "rectangle.stack",
        },
        {
          id: 3,
          title: "Búsqueda en Internet",
          content:
            "Los motores de búsqueda como Google te ayudan a encontrar información. Escribe palabras clave y obtendrás resultados relevantes. Usa comillas para buscar frases exactas y palabras específicas para obtener mejores resultados.",
          icon: "magnifyingglass",
        },
        {
          id: 4,
          title: "Marcadores y Favoritos",
          content:
            "Los marcadores te permiten guardar páginas web que visitas frecuentemente. Es como crear una lista de 'páginas favoritas' para acceder rápidamente sin tener que recordar la dirección completa.",
          icon: "bookmark",
        },
      ],
    },
    "online-security": {
      title: "Seguridad en Línea",
      description:
        "Protege tu información personal y navega de forma segura en internet.",
      concepts: [
        {
          id: 1,
          title: "Amenazas en Internet",
          content:
            "• Virus: Programas maliciosos que dañan tu computadora\n• Phishing: Intentos de engaño para obtener información personal\n• Malware: Software malicioso que roba información\n• Spam: Mensajes no deseados y publicidad molesta",
          icon: "exclamationmark.triangle",
        },
        {
          id: 2,
          title: "Contraseñas Seguras",
          content:
            "• Usa al menos 8 caracteres\n• Combina letras mayúsculas y minúsculas\n• Incluye números y símbolos\n• No uses información personal\n• Usa contraseñas diferentes para cada cuenta",
          icon: "key",
        },
        {
          id: 3,
          title: "Sitios Web Seguros",
          content:
            "Siempre verifica que los sitios web sean seguros antes de ingresar información personal. Busca el candado verde en la barra de direcciones y que la URL comience con 'HTTPS' en lugar de 'HTTP'.",
          icon: "lock.shield",
        },
        {
          id: 4,
          title: "Protección de Privacidad",
          content:
            "• No compartas información personal con desconocidos\n• Configura la privacidad en redes sociales\n• Ten cuidado con lo que publicas en línea\n• Usa configuraciones de privacidad en navegadores\n• Mantén tu software actualizado",
          icon: "hand.raised",
        },
      ],
    },
    "email-concepts": {
      title: "Conceptos de Email",
      description:
        "Entiende qué es el email y cómo funciona la comunicación digital.",
      concepts: [
        {
          id: 1,
          title: "¿Qué es el Email?",
          content:
            "El email (correo electrónico) es un servicio que permite enviar y recibir mensajes digitales a través de internet. Es como enviar una carta, pero instantánea y digital. Cada persona tiene una dirección única (ejemplo@servicio.com).",
          icon: "envelope",
        },
        {
          id: 2,
          title: "Partes de un Email",
          content:
            "• Para: Dirección del destinatario\n• De: Tu dirección de email\n• Asunto: Tema del mensaje\n• Cuerpo: El mensaje principal\n• Adjuntos: Archivos que puedes enviar\n• CC/CCO: Copias a otros destinatarios",
          icon: "doc.text",
        },
        {
          id: 3,
          title: "Crear una Cuenta de Email",
          content:
            "Para usar email necesitas crear una cuenta en un proveedor como Gmail, Outlook o Yahoo. Elige un nombre de usuario único y una contraseña segura. Tu dirección será: usuario@proveedor.com",
          icon: "person.badge.plus",
        },
        {
          id: 4,
          title: "Buenas Prácticas",
          content:
            "• Revisa la dirección del destinatario antes de enviar\n• Escribe un asunto claro y descriptivo\n• Mantén un tono profesional\n• Revisa la ortografía antes de enviar\n• No envíes información sensible por email",
          icon: "checkmark.circle",
        },
      ],
    },
    "messaging-apps": {
      title: "Aplicaciones de Mensajería",
      description:
        "Aprende sobre WhatsApp, Telegram y otras aplicaciones de comunicación instantánea.",
      concepts: [
        {
          id: 1,
          title: "¿Qué son las Apps de Mensajería?",
          content:
            "Las aplicaciones de mensajería como WhatsApp, Telegram, Messenger permiten enviar mensajes instantáneos, fotos, videos y hacer llamadas. Son más rápidas que el email pero menos formales.",
          icon: "message",
        },
        {
          id: 2,
          title: "Características Principales",
          content:
            "• Mensajes instantáneos\n• Envío de fotos y videos\n• Llamadas de voz y video\n• Grupos de chat\n• Estados/Historias\n• Emojis y stickers",
          icon: "bubble.left.and.bubble.right",
        },
        {
          id: 3,
          title: "Configuración de Privacidad",
          content:
            "• Controla quién puede ver tu foto de perfil\n• Configura quién puede agregarte a grupos\n• Decide quién puede ver tu estado en línea\n• Bloquea usuarios no deseados\n• Usa verificación en dos pasos",
          icon: "lock",
        },
        {
          id: 4,
          title: "Uso Responsable",
          content:
            "• No envíes mensajes a altas horas de la noche\n• Respeta el tiempo de respuesta de otros\n• No compartas información personal\n• Ten cuidado con enlaces sospechosos\n• No uses para acosar o molestar",
          icon: "hand.raised",
        },
      ],
    },
    "digital-etiquette": {
      title: "Netiqueta Digital",
      description:
        "Buenas prácticas para comunicarse de forma respetuosa en línea.",
      concepts: [
        {
          id: 1,
          title: "¿Qué es la Netiqueta?",
          content:
            "La netiqueta son las reglas de comportamiento y cortesía en internet. Es como la 'etiqueta' digital que nos ayuda a comunicarnos de forma respetuosa y efectiva en línea.",
          icon: "hand.raised",
        },
        {
          id: 2,
          title: "Reglas Básicas",
          content:
            "• Saluda y despídete apropiadamente\n• Usa un lenguaje respetuoso\n• No escribas todo en mayúsculas (es como gritar)\n• Revisa antes de enviar\n• No envíes spam o mensajes no solicitados",
          icon: "list.bullet",
        },
        {
          id: 3,
          title: "Comunicación en Grupos",
          content:
            "• Mantén las conversaciones relevantes al tema\n• No monopolices la conversación\n• Respeta las opiniones de otros\n• No envíes mensajes repetitivos\n• Usa el tono apropiado para el contexto",
          icon: "person.3",
        },
        {
          id: 4,
          title: "Respeto por el Tiempo",
          content:
            "• No envíes mensajes urgentes a altas horas\n• Respeta los horarios de trabajo\n• No esperes respuestas inmediatas\n• Usa 'urgente' solo cuando sea necesario\n• Considera las zonas horarias",
          icon: "clock",
        },
      ],
    },
    "word-processors": {
      title: "Procesadores de Texto",
      description:
        "Aprende a usar Word, Google Docs y otras herramientas para crear documentos.",
      concepts: [
        {
          id: 1,
          title: "¿Qué es un Procesador de Texto?",
          content:
            "Un procesador de texto es un programa que te permite crear, editar y formatear documentos escritos. Es como una máquina de escribir digital pero mucho más potente. Los más populares son Microsoft Word y Google Docs.",
          icon: "doc.text",
        },
        {
          id: 2,
          title: "Funciones Básicas",
          content:
            "• Escribir y editar texto\n• Cambiar el formato (negrita, cursiva, subrayado)\n• Ajustar el tamaño y tipo de letra\n• Agregar imágenes y gráficos\n• Crear listas y tablas\n• Guardar y compartir documentos",
          icon: "textformat",
        },
        {
          id: 3,
          title: "Formato de Texto",
          content:
            "• Negrita: Para enfatizar texto importante\n• Cursiva: Para títulos o palabras extranjeras\n• Subrayado: Para enlaces o énfasis\n• Tamaño de fuente: Para jerarquía visual\n• Color: Para destacar información",
          icon: "paintbrush",
        },
        {
          id: 4,
          title: "Guardar y Compartir",
          content:
            "• Guarda tu trabajo frecuentemente\n• Usa nombres descriptivos para los archivos\n• Haz copias de seguridad\n• Comparte documentos usando enlaces\n• Colabora en tiempo real con otros",
          icon: "square.and.arrow.up",
        },
      ],
    },
    spreadsheets: {
      title: "Hojas de Cálculo",
      description:
        "Domina Excel, Google Sheets y otras herramientas para organizar datos y hacer cálculos.",
      concepts: [
        {
          id: 1,
          title: "¿Qué es una Hoja de Cálculo?",
          content:
            "Una hoja de cálculo es un programa que te permite organizar datos en filas y columnas, hacer cálculos automáticos, crear gráficos y analizar información. Es útil para presupuestos, listas, estadísticas y más.",
          icon: "tablecells",
        },
        {
          id: 2,
          title: "Estructura Básica",
          content:
            "• Filas: Números horizontales (1, 2, 3...)\n• Columnas: Letras verticales (A, B, C...)\n• Celdas: Intersección de filas y columnas\n• Fórmulas: Cálculos automáticos\n• Funciones: Operaciones predefinidas",
          icon: "grid",
        },
        {
          id: 3,
          title: "Fórmulas Básicas",
          content:
            "• Suma: =SUMA(A1:A10)\n• Promedio: =PROMEDIO(B1:B20)\n• Multiplicación: =A1*B1\n• División: =A1/B1\n• Porcentaje: =A1*0.1",
          icon: "plus.forwardslash.minus",
        },
        {
          id: 4,
          title: "Gráficos y Visualización",
          content:
            "• Gráficos de barras: Para comparar cantidades\n• Gráficos de líneas: Para mostrar tendencias\n• Gráficos circulares: Para mostrar proporciones\n• Tablas dinámicas: Para analizar datos complejos",
          icon: "chart.bar",
        },
      ],
    },
    presentations: {
      title: "Presentaciones",
      description:
        "Crea presentaciones impactantes con PowerPoint, Google Slides y otras herramientas.",
      concepts: [
        {
          id: 1,
          title: "¿Qué es una Presentación?",
          content:
            "Una presentación es un conjunto de diapositivas con texto, imágenes y videos para mostrar información de forma visual. Es útil para exposiciones, reuniones, clases y conferencias. Los programas más populares son PowerPoint y Google Slides.",
          icon: "rectangle.stack",
        },
        {
          id: 2,
          title: "Elementos de una Presentación",
          content:
            "• Diapositiva de título: Introduce el tema\n• Diapositivas de contenido: Información principal\n• Imágenes y gráficos: Apoyo visual\n• Transiciones: Efectos entre diapositivas\n• Animaciones: Movimiento de elementos",
          icon: "photo.on.rectangle",
        },
        {
          id: 3,
          title: "Diseño Efectivo",
          content:
            "• Usa pocas palabras por diapositiva\n• Mantén consistencia en colores y fuentes\n• Usa imágenes relevantes y de calidad\n• Limita las animaciones\n• Asegúrate de que el texto sea legible",
          icon: "paintpalette",
        },
        {
          id: 4,
          title: "Consejos para Presentar",
          content:
            "• Practica tu presentación varias veces\n• Mantén contacto visual con la audiencia\n• Habla claro y a un ritmo apropiado\n• Usa el modo presentador para ver notas\n• Ten un plan de respaldo por si hay problemas técnicos",
          icon: "person.wave.2",
        },
      ],
    },
    "social-media-concepts": {
      title: "Conceptos de Redes Sociales",
      description:
        "Entiende qué son las redes sociales y cómo funcionan las plataformas digitales.",
      concepts: [
        {
          id: 1,
          title: "¿Qué son las Redes Sociales?",
          content:
            "Las redes sociales son plataformas digitales que permiten conectar con otras personas, compartir contenido y comunicarse. Ejemplos: Facebook, Instagram, Twitter, LinkedIn. Son como 'plazas públicas' digitales donde la gente se reúne virtualmente.",
          icon: "person.3",
        },
        {
          id: 2,
          title: "Tipos de Redes Sociales",
          content:
            "• Facebook: Conexión con amigos y familia\n• Instagram: Compartir fotos y videos\n• Twitter: Noticias y conversaciones cortas\n• LinkedIn: Networking profesional\n• TikTok: Videos cortos y entretenimiento\n• YouTube: Videos y tutoriales",
          icon: "apps.iphone",
        },
        {
          id: 3,
          title: "Funciones Principales",
          content:
            "• Perfil personal: Tu información y fotos\n• Publicaciones: Compartir contenido\n• Seguir/Amigos: Conectar con otros\n• Mensajes privados: Comunicación directa\n• Historias: Contenido temporal\n• Grupos: Comunidades de interés",
          icon: "list.bullet",
        },
        {
          id: 4,
          title: "Impacto en la Sociedad",
          content:
            "• Comunicación global instantánea\n• Difusión de información y noticias\n• Oportunidades de networking\n• Plataforma para negocios y marketing\n• Espacio para activismo social\n• Riesgos de adicción y comparación social",
          icon: "globe",
        },
      ],
    },
    "privacy-settings": {
      title: "Configuración de Privacidad",
      description:
        "Protege tu información personal configurando la privacidad en redes sociales.",
      concepts: [
        {
          id: 1,
          title: "¿Por qué es Importante la Privacidad?",
          content:
            "La privacidad en redes sociales es crucial para proteger tu información personal, evitar el acoso, prevenir el robo de identidad y mantener el control sobre quién puede ver tu contenido. Es tu derecho decidir qué compartir y con quién.",
          icon: "lock",
        },
        {
          id: 2,
          title: "Configuraciones Básicas",
          content:
            "• Perfil público vs privado\n• Quién puede ver tus publicaciones\n• Quién puede enviarte mensajes\n• Quién puede agregarte como amigo\n• Visibilidad de tu información de contacto\n• Configuración de ubicación",
          icon: "gearshape",
        },
        {
          id: 3,
          title: "Información Personal a Proteger",
          content:
            "• Dirección y número de teléfono\n• Fecha de nacimiento completa\n• Información financiera\n• Ubicación en tiempo real\n• Fotos de documentos oficiales\n• Información familiar sensible",
          icon: "person.crop.circle.badge.exclamationmark",
        },
        {
          id: 4,
          title: "Herramientas de Privacidad",
          content:
            "• Bloqueo de usuarios molestos\n• Reporte de contenido inapropiado\n• Configuración de notificaciones\n• Verificación en dos pasos\n• Historial de actividad\n• Eliminación de datos",
          icon: "shield",
        },
      ],
    },
    "responsible-content": {
      title: "Contenido Responsable",
      description:
        "Buenas prácticas para publicar contenido de forma responsable en redes sociales.",
      concepts: [
        {
          id: 1,
          title: "Pensar Antes de Publicar",
          content:
            "Antes de publicar algo en redes sociales, pregúntate: ¿Es verdadero? ¿Es útil? ¿Es inspirador? ¿Es necesario? ¿Es amable? Una vez que publicas algo, puede ser difícil de eliminar completamente.",
          icon: "brain.head.profile",
        },
        {
          id: 2,
          title: "Contenido Apropiado",
          content:
            "• Comparte contenido positivo y constructivo\n• Respeta los derechos de autor\n• No difundas información falsa\n• Evita contenido ofensivo o discriminatorio\n• Considera el impacto en otros\n• Mantén un tono respetuoso",
          icon: "checkmark.circle",
        },
        {
          id: 3,
          title: "Huella Digital",
          content:
            "Todo lo que publicas en internet deja una 'huella digital' permanente. Los empleadores, universidades y otras personas pueden ver tu historial en línea. Mantén una reputación digital positiva.",
          icon: "footprints",
        },
        {
          id: 4,
          title: "Interacción Respetuosa",
          content:
            "• Comenta de forma constructiva\n• No participes en discusiones tóxicas\n• Respeta las opiniones diferentes\n• No uses redes sociales para acosar\n• Reporta contenido inapropiado\n• Sé un ejemplo positivo",
          icon: "hand.raised",
        },
      ],
    },
    "digital-threats": {
      title: "Amenazas Digitales",
      description:
        "Conoce los virus, malware, phishing y otras amenazas comunes en internet.",
      concepts: [
        {
          id: 1,
          title: "¿Qué son las Amenazas Digitales?",
          content:
            "Las amenazas digitales son programas maliciosos o técnicas que intentan dañar tu computadora, robar información personal o engañarte. Es importante conocerlas para protegerte y navegar de forma segura en internet.",
          icon: "exclamationmark.triangle",
        },
        {
          id: 2,
          title: "Tipos de Malware",
          content:
            "• Virus: Se replica y daña archivos\n• Troyanos: Se disfraza de software legítimo\n• Spyware: Espía tu actividad en línea\n• Ransomware: Bloquea tu computadora y pide rescate\n• Adware: Muestra publicidad no deseada",
          icon: "ant",
        },
        {
          id: 3,
          title: "Phishing",
          content:
            "El phishing son intentos de engaño para obtener información personal como contraseñas, números de tarjeta de crédito o datos bancarios. Los atacantes se hacen pasar por empresas legítimas a través de emails o sitios web falsos.",
          icon: "fish",
        },
        {
          id: 4,
          title: "Cómo Protegerse",
          content:
            "• Instala y mantén actualizado un antivirus\n• No hagas clic en enlaces sospechosos\n• No descargues archivos de fuentes desconocidas\n• Mantén tu software actualizado\n• Usa contraseñas fuertes\n• Ten cuidado con emails no solicitados",
          icon: "shield",
        },
      ],
    },
    "secure-passwords": {
      title: "Contraseñas Seguras",
      description:
        "Aprende a crear contraseñas fuertes y proteger tus cuentas en línea.",
      concepts: [
        {
          id: 1,
          title: "¿Por qué son Importantes las Contraseñas?",
          content:
            "Las contraseñas son la primera línea de defensa para proteger tus cuentas en línea. Una contraseña débil puede permitir que hackers accedan a tu información personal, cuentas bancarias, redes sociales y más.",
          icon: "key",
        },
        {
          id: 2,
          title: "Características de una Contraseña Fuerte",
          content:
            "• Al menos 8 caracteres (12 o más es mejor)\n• Letras mayúsculas y minúsculas\n• Números (0-9)\n• Símbolos especiales (!@#$%^&*)\n• No usar información personal\n• No usar palabras del diccionario",
          icon: "checkmark.shield",
        },
        {
          id: 3,
          title: "Ejemplos de Contraseñas Seguras",
          content:
            "• M1c@r0n4#2024!\n• P@ssw0rd$tr0ng!\n• B1gC@t#L0v3r\n• S3cur3#P@ss!\n• T3ch#N3rd$2024\n\nEvita: password123, 123456, qwerty, tu nombre",
          icon: "textformat.abc",
        },
        {
          id: 4,
          title: "Gestión de Contraseñas",
          content:
            "• Usa contraseñas diferentes para cada cuenta\n• Cambia las contraseñas regularmente\n• Usa un gestor de contraseñas\n• No compartas contraseñas\n• Activa la verificación en dos pasos\n• Guarda las contraseñas de forma segura",
          icon: "lock.rotation",
        },
      ],
    },
    "two-factor-auth": {
      title: "Autenticación de Dos Factores",
      description:
        "Añade una capa extra de seguridad a tus cuentas con verificación en dos pasos.",
      concepts: [
        {
          id: 1,
          title: "¿Qué es la Autenticación de Dos Factores?",
          content:
            "La autenticación de dos factores (2FA) añade una capa extra de seguridad a tus cuentas. Además de tu contraseña, necesitas un segundo factor (código, huella dactilar, etc.) para acceder. Esto hace mucho más difícil que alguien acceda a tu cuenta.",
          icon: "lock.shield",
        },
        {
          id: 2,
          title: "Tipos de Segundos Factores",
          content:
            "• Códigos SMS: Se envían a tu teléfono\n• Aplicaciones autenticadoras: Google Authenticator, Authy\n• Llaves de seguridad físicas: Dispositivos USB\n• Huellas dactilares: Biometría\n• Reconocimiento facial: Face ID",
          icon: "iphone",
        },
        {
          id: 3,
          title: "Cómo Configurar 2FA",
          content:
            "1. Ve a la configuración de seguridad de tu cuenta\n2. Busca 'Verificación en dos pasos' o '2FA'\n3. Sigue las instrucciones para activarlo\n4. Escanea el código QR con tu app autenticadora\n5. Guarda los códigos de respaldo en un lugar seguro",
          icon: "gearshape.2",
        },
        {
          id: 4,
          title: "Cuándo Usar 2FA",
          content:
            "• Cuentas bancarias y financieras\n• Email principal\n• Redes sociales importantes\n• Cuentas de trabajo\n• Almacenamiento en la nube\n• Cualquier cuenta con información sensible",
          icon: "checklist",
        },
      ],
    },
  };

  const currentConcept = conceptData[conceptScreen as keyof typeof conceptData];

  const renderConcept = (concept: any) => {
    const isExpanded = expandedConcept === concept.id;

    return (
      <TouchableOpacity
        key={concept.id}
        className="bg-white rounded-xl p-4 mb-3 border border-gray-100"
        onPress={() => setExpandedConcept(isExpanded ? null : concept.id)}
      >
        <View className="flex-row items-center">
          <View className="w-12 h-12 rounded-full bg-blue-100 items-center justify-center mr-4">
            <IconSymbol name={concept.icon as any} size={24} color="#3B82F6" />
          </View>
          <View className="flex-1">
            <Text className="text-base font-bold text-gray-800 mb-1">
              {concept.title}
            </Text>
            {isExpanded && (
              <Text className="text-sm text-gray-600 leading-5 mt-2">
                {concept.content}
              </Text>
            )}
          </View>
          <IconSymbol
            name={isExpanded ? "chevron.up" : "chevron.down"}
            size={20}
            color="#9CA3AF"
          />
        </View>
      </TouchableOpacity>
    );
  };

  if (!currentConcept) {
    return (
      <View className="flex-1 bg-gray-50 items-center justify-center">
        <Text className="text-lg text-gray-600">Contenido no encontrado</Text>
      </View>
    );
  }

  return (
    <>
      <StatusBar barStyle="dark-content" />
      <View
        className="flex-1 bg-gray-50"
        style={{
          paddingTop: getTopPadding(),
          paddingBottom: getBottomPadding(),
        }}
      >
        {/* Header */}
        <View className="flex-row items-center px-6 mb-6">
          <TouchableOpacity className="mr-4" onPress={() => router.back()}>
            <IconSymbol name="chevron.left" size={24} color="#000" />
          </TouchableOpacity>
          <Text className="text-xl font-bold text-black">
            {currentConcept.title}
          </Text>
        </View>

        <ScrollView
          className="flex-1 px-6"
          showsVerticalScrollIndicator={false}
        >
          {/* Description */}
          <View className="mb-6">
            <Text className="text-base text-gray-600 leading-6">
              {currentConcept.description}
            </Text>
          </View>

          {/* Concepts */}
          <View className="mb-8">
            {currentConcept.concepts.map((concept: any) =>
              renderConcept(concept)
            )}
          </View>
        </ScrollView>
      </View>
    </>
  );
}
