import { useEffect, useState } from "react";

interface AuthState {
  isAuthenticated: boolean;
  isLoading: boolean;
  user: any | null;
}

interface AuthContextType extends AuthState {
  login: () => Promise<void>;
  logout: () => Promise<void>;
  signup: () => Promise<void>;
}

// Mock authentication hook
export const useAuth = (): AuthContextType => {
  const [authState, setAuthState] = useState<AuthState>({
    isAuthenticated: false,
    isLoading: true,
    user: null,
  });

  // Simulate checking authentication status on app start
  useEffect(() => {
    const checkAuthStatus = async () => {
      // Simulate API call delay
      await new Promise((resolve) => setTimeout(resolve, 1000));

      // For now, always start as not authenticated
      // You can change this to true to test the authenticated flow
      setAuthState({
        isAuthenticated: false,
        isLoading: false,
        user: null,
      });
    };

    checkAuthStatus();
  }, []);

  const login = async () => {
    setAuthState((prev) => ({ ...prev, isLoading: true }));

    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 1000));

    setAuthState({
      isAuthenticated: true,
      isLoading: false,
      user: { id: "1", name: "Mock User" },
    });
  };

  const logout = async () => {
    setAuthState((prev) => ({ ...prev, isLoading: true }));

    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 500));

    setAuthState({
      isAuthenticated: false,
      isLoading: false,
      user: null,
    });
  };

  const signup = async () => {
    setAuthState((prev) => ({ ...prev, isLoading: true }));

    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 1000));

    setAuthState({
      isAuthenticated: true,
      isLoading: false,
      user: { id: "1", name: "New Mock User" },
    });
  };

  return {
    ...authState,
    login,
    logout,
    signup,
  };
};
