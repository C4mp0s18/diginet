import { Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

export const useDeviceInfo = () => {
  const insets = useSafeAreaInsets();

  // Detect if device has Dynamic Island (iPhone 14 Pro and newer)
  const hasDynamicIsland = Platform.OS === "ios" && insets.top > 50;

  // Detect if device has notch (iPhone X and newer, but not Dynamic Island)
  const hasNotch = Platform.OS === "ios" && insets.top > 20 && insets.top <= 50;

  // Get appropriate top padding based on device
  const getTopPadding = (basePadding: number = 10) => {
    if (hasDynamicIsland) {
      return insets.top + 20; // Extra padding for Dynamic Island
    } else if (hasNotch) {
      return insets.top + 10; // Standard padding for notch
    } else {
      return basePadding; // Minimal padding for devices without notch
    }
  };

  // Get appropriate bottom padding
  const getBottomPadding = (basePadding: number = 0) => {
    return Math.max(insets.bottom, basePadding);
  };

  return {
    insets,
    hasDynamicIsland,
    hasNotch,
    getTopPadding,
    getBottomPadding,
    isIOS: Platform.OS === "ios",
    isAndroid: Platform.OS === "android",
    isWeb: Platform.OS === "web",
  };
};
