import { Button, ButtonText } from "@/components/ui/button";
import { IconSymbol } from "@/components/ui/IconSymbol";
import { useAuth } from "@/hooks/useAuth";
import { useDeviceInfo } from "@/hooks/useDeviceInfo";
import { Stack, useRouter } from "expo-router";
import React, { useState } from "react";
import {
  StatusBar,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

export default function SignupScreen() {
  const router = useRouter();
  const { signup, isLoading } = useAuth();
  const { getTopPadding, getBottomPadding } = useDeviceInfo();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSignup = async () => {
    if (!name.trim() || !email.trim() || !password.trim()) {
      // You could add proper validation here
      return;
    }

    try {
      await signup();
      router.replace("/(tabs)");
    } catch (error) {
      console.error("Signup failed:", error);
    }
  };

  return (
    <>
      <Stack.Screen
        options={{
          title: "Crear cuenta",
          headerShown: false,
        }}
      />
      <StatusBar barStyle="dark-content" />

      <View
        className="flex-1 bg-white"
        style={{
          paddingTop: getTopPadding(),
          paddingBottom: getBottomPadding(),
          paddingHorizontal: 24,
        }}
      >
        {/* Back Button */}
        <View className="flex-row items-center mb-8">
          <TouchableOpacity onPress={() => router.navigate("/(auth)/landing")}>
            <IconSymbol
              name="chevron.right"
              size={24}
              color="#000"
              style={{ transform: [{ rotate: "180deg" }] }}
            />
          </TouchableOpacity>
        </View>

        {/* Header */}
        <View className="mb-8">
          <Text className="text-3xl font-bold text-black mb-2">
            Crear cuenta
          </Text>
          <Text className="text-base text-gray-500">
            Vamos a empezar tu viaje de aprendizaje.
          </Text>
        </View>

        {/* Form Fields */}
        <View className="flex-1">
          {/* Name Field */}
          <View className="mb-6">
            <Text className="text-base font-medium text-black mb-2">
              Nombre completo
            </Text>
            <View className="bg-gray-100 rounded-xl p-4">
              <TextInput
                className="text-base text-black"
                placeholder="Ingresa tu nombre completo"
                placeholderTextColor="#9CA3AF"
                value={name}
                onChangeText={setName}
                autoCapitalize="words"
                autoComplete="name"
              />
            </View>
          </View>

          {/* Email Field */}
          <View className="mb-6">
            <Text className="text-base font-medium text-black mb-2">
              Correo electrónico
            </Text>
            <View className="bg-gray-100 rounded-xl p-4">
              <TextInput
                className="text-base text-black"
                placeholder="tu@correo.com"
                placeholderTextColor="#9CA3AF"
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                autoComplete="email"
              />
            </View>
          </View>

          {/* Password Field */}
          <View className="mb-8">
            <Text className="text-base font-medium text-black mb-2">
              Contraseña
            </Text>
            <View className="bg-gray-100 rounded-xl p-4">
              <TextInput
                className="text-base text-black"
                placeholder="Crea una contraseña segura"
                placeholderTextColor="#9CA3AF"
                value={password}
                onChangeText={setPassword}
                secureTextEntry={false}
                autoComplete="new-password"
              />
            </View>
          </View>

          {/* Sign Up Button */}
          <Button
            variant="solid"
            className="w-full bg-blue-500 rounded-xl h-14 mb-6"
            onPress={handleSignup}
            disabled={
              isLoading || !name.trim() || !email.trim() || !password.trim()
            }
          >
            <ButtonText className="text-white font-bold text-lg">
              {isLoading ? "Creando cuenta..." : "Crear cuenta"}
            </ButtonText>
          </Button>

          {/* Footer Link */}
          <View className="flex-row justify-center">
            <Text className="text-base text-gray-500">
              Ya tienes una cuenta?{" "}
            </Text>
            <Text
              className="text-base text-blue-500 font-medium"
              onPress={() => router.navigate("/(auth)/login")}
            >
              Iniciar sesión
            </Text>
          </View>
        </View>
      </View>
    </>
  );
}
