import { IconSymbol } from "@/components/ui/IconSymbol";
import { useAuth } from "@/hooks/useAuth";
import { useDeviceInfo } from "@/hooks/useDeviceInfo";
import { useRouter } from "expo-router";
import React from "react";
import {
  ScrollView,
  StatusBar,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

export default function HomeScreen() {
  const router = useRouter();
  const { user } = useAuth();
  const { getTopPadding, getBottomPadding } = useDeviceInfo();

  const resourceCards = [
    {
      id: 1,
      title: "Programas de Alfabetización",
      description: "Mejora tu lectura y escritura",
      icon: "book.fill",
      color: "#E3F2FD",
    },
    {
      id: 2,
      title: "Talleres de Habilidades Digitales",
      description: "Aprende lo básico de computación",
      icon: "lightbulb.fill",
      color: "#E8F5E8",
    },
    {
      id: 3,
      title: "Biblioteca Comunitaria",
      description: "Encuentra libros y materiales",
      icon: "graduationcap.fill",
      color: "#FFF3E0",
    },
    {
      id: 4,
      title: "Aprendizaje en Línea",
      description: "Accede a cursos en línea",
      icon: "paperplane.fill",
      color: "#F3E5F5",
    },
  ];

  return (
    <>
      <StatusBar barStyle="dark-content" />
      <View
        className="flex-1 bg-white"
        style={{
          paddingTop: getTopPadding(),
          paddingBottom: getBottomPadding(),
        }}
      >
        {/* Header */}
        <View className="flex-row items-center justify-between px-6 mb-6">
          <TouchableOpacity>
            <IconSymbol name="menu" size={24} color="#000" />
          </TouchableOpacity>
          <Text className="text-xl font-bold text-black">Inicio</Text>
          <TouchableOpacity>
            <IconSymbol name="bell" size={24} color="#000" />
          </TouchableOpacity>
        </View>

        <ScrollView
          className="flex-1 px-6"
          showsVerticalScrollIndicator={false}
        >
          {/* Welcome Section */}
          <View className="mb-8">
            <Text className="text-2xl font-bold text-black mb-2">
              ¡Bienvenido, {user?.name || "Sebas"}!
            </Text>
            <Text className="text-base text-gray-600">
              Explora los recursos disponibles en tu área.
            </Text>
          </View>

          {/* Resource Cards Grid */}
          <View className="flex-row flex-wrap justify-between">
            {resourceCards.map((card) => (
              <TouchableOpacity
                key={card.id}
                className="w-[48%] mb-4 p-4 rounded-xl"
                style={{ backgroundColor: card.color }}
                onPress={() => {
                  // Handle card press
                  console.log(`Pressed: ${card.title}`);
                }}
              >
                <View className="items-center">
                  <IconSymbol
                    name={card.icon as any}
                    size={40}
                    color="#3B82F6"
                    style={{ marginBottom: 12 }}
                  />
                  <Text className="text-sm font-bold text-black text-center mb-2">
                    {card.title}
                  </Text>
                  <Text className="text-xs text-gray-600 text-center">
                    {card.description}
                  </Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>
      </View>
    </>
  );
}
