import { IconSymbol } from "@/components/ui/IconSymbol";
import { useAuth } from "@/hooks/useAuth";
import { useDeviceInfo } from "@/hooks/useDeviceInfo";
import React from "react";
import {
  ScrollView,
  StatusBar,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

export default function LibraryScreen() {
  const { user } = useAuth();
  const { getTopPadding, getBottomPadding } = useDeviceInfo();

  const courses = [
    {
      id: 1,
      subject: "Informática Básica",
      title: "Fundamentos de Computación",
      description:
        "Aprende los conceptos básicos de computación, desde encender una computadora hasta navegar por internet de forma segura.",
      thumbnail: "💻",
      color: "#3B82F6",
    },
    {
      id: 2,
      subject: "Internet y Navegación",
      title: "Navegación Segura en la Web",
      description:
        "Explora cómo usar internet de manera segura, identificar información confiable y proteger tu privacidad en línea.",
      thumbnail: "🌐",
      color: "#10B981",
    },
    {
      id: 3,
      subject: "Comunicación Digital",
      title: "Email y Mensajería",
      description:
        "Aprende a crear y gestionar cuentas de correo electrónico, enviar mensajes y usar aplicaciones de comunicación.",
      thumbnail: "📧",
      color: "#F59E0B",
    },
    {
      id: 4,
      subject: "Herramientas Digitales",
      title: "Productividad en Línea",
      description:
        "Descubre herramientas digitales para crear documentos, hojas de cálculo y presentaciones básicas.",
      thumbnail: "📊",
      color: "#8B5CF6",
    },
    {
      id: 5,
      subject: "Redes Sociales",
      title: "Uso Responsable de Redes",
      description:
        "Aprende a usar las redes sociales de manera segura, crear contenido y conectar con otros de forma responsable.",
      thumbnail: "📱",
      color: "#EC4899",
    },
    {
      id: 6,
      subject: "Seguridad Digital",
      title: "Protección en Línea",
      description:
        "Conoce las mejores prácticas para proteger tu información personal y evitar estafas en internet.",
      thumbnail: "🔒",
      color: "#EF4444",
    },
  ];

  return (
    <>
      <StatusBar barStyle="dark-content" />
      <View
        className="flex-1 bg-gray-50"
        style={{
          paddingTop: getTopPadding(),
          paddingBottom: getBottomPadding(),
        }}
      >
        {/* Header */}
        <View className="flex-row items-center justify-between px-6 mb-6">
          <View>
            <Text className="text-2xl font-bold text-gray-800">Biblioteca</Text>
            <Text className="text-base text-gray-600">
              Continuemos aprendiendo.
            </Text>
          </View>
          <TouchableOpacity className="w-10 h-10 bg-gray-200 rounded-full items-center justify-center">
            <IconSymbol name="bell" size={20} color="#6B7280" />
          </TouchableOpacity>
        </View>

        <ScrollView
          className="flex-1 px-6"
          showsVerticalScrollIndicator={false}
        >
          {/* Course Cards */}
          {courses.map((course) => (
            <TouchableOpacity
              key={course.id}
              className="bg-white rounded-xl p-4 mb-4 shadow-sm border border-gray-100"
              onPress={() => {
                // Handle course selection
                console.log(`Selected course: ${course.title}`);
              }}
            >
              <View className="flex-row">
                {/* Course Content */}
                <View className="flex-1 mr-4">
                  <Text
                    className="text-sm font-medium mb-1"
                    style={{ color: course.color }}
                  >
                    {course.subject}
                  </Text>
                  <Text className="text-lg font-bold text-gray-800 mb-2">
                    {course.title}
                  </Text>
                  <Text className="text-sm text-gray-600 leading-5">
                    {course.description}
                  </Text>
                </View>

                {/* Thumbnail */}
                <View className="w-16 h-16 rounded-lg items-center justify-center">
                  <Text className="text-2xl">{course.thumbnail}</Text>
                </View>
              </View>
            </TouchableOpacity>
          ))}

          {/* Additional Resources Section */}
          <View className="mt-6 mb-8">
            <Text className="text-lg font-bold text-gray-800 mb-4">
              Recursos Adicionales
            </Text>

            <View className="bg-white rounded-xl p-4 border border-gray-200">
              <TouchableOpacity className="flex-row items-center justify-between mb-3">
                <View className="flex-row items-center">
                  <View className="w-10 h-10 bg-blue-100 rounded-lg items-center justify-center mr-3">
                    <IconSymbol
                      name="graduationcap.fill"
                      size={20}
                      color="#3B82F6"
                    />
                  </View>
                  <Text className="text-base font-medium text-gray-800">
                    Certificaciones Digitales
                  </Text>
                </View>
                <IconSymbol name="chevron.right" size={20} color="#9CA3AF" />
              </TouchableOpacity>

              <TouchableOpacity className="flex-row items-center justify-between mb-3">
                <View className="flex-row items-center">
                  <View className="w-10 h-10 bg-green-100 rounded-lg items-center justify-center mr-3">
                    <IconSymbol
                      name="lightbulb.fill"
                      size={20}
                      color="#10B981"
                    />
                  </View>
                  <Text className="text-base font-medium text-gray-800">
                    Talleres Prácticos
                  </Text>
                </View>
                <IconSymbol name="chevron.right" size={20} color="#9CA3AF" />
              </TouchableOpacity>

              <TouchableOpacity className="flex-row items-center justify-between">
                <View className="flex-row items-center">
                  <View className="w-10 h-10 bg-purple-100 rounded-lg items-center justify-center mr-3">
                    <IconSymbol name="book.fill" size={20} color="#8B5CF6" />
                  </View>
                  <Text className="text-base font-medium text-gray-800">
                    Biblioteca de Referencia
                  </Text>
                </View>
                <IconSymbol name="chevron.right" size={20} color="#9CA3AF" />
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </View>
    </>
  );
}
