import { IconSymbol } from "@/components/ui/IconSymbol";
import { useAuth } from "@/hooks/useAuth";
import { useDeviceInfo } from "@/hooks/useDeviceInfo";
import React from "react";
import {
  ScrollView,
  StatusBar,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

export default function ProfileScreen() {
  const { user } = useAuth();
  const { getTopPadding, getBottomPadding } = useDeviceInfo();

  const progressData = [
    { subject: "Matemáticas", progress: 75, color: "#3B82F6" },
    { subject: "Ciencias", progress: 50, color: "#10B981" },
    { subject: "Historia", progress: 25, color: "#F59E0B" },
  ];

  return (
    <>
      <StatusBar barStyle="dark-content" />
      <View
        className="flex-1 bg-white"
        style={{
          paddingTop: getTopPadding(),
          paddingBottom: getBottomPadding(),
        }}
      >
        {/* Header */}
        <View className="flex-row items-center justify-between px-6 mb-6">
          <View style={{ width: 24 }} />
          <Text className="text-xl font-bold text-black">Perfil</Text>
          <TouchableOpacity>
            <IconSymbol name="bell" size={24} color="#000" />
          </TouchableOpacity>
        </View>

        <ScrollView
          className="flex-1 px-6"
          showsVerticalScrollIndicator={false}
        >
          {/* Profile Picture and Info */}
          <View className="items-center mb-8">
            <View className="w-24 h-24 rounded-full bg-orange-100 items-center justify-center mb-4">
              <Text className="text-4xl">👩‍🎓</Text>
            </View>
            <Text className="text-2xl font-bold text-black mb-1">
              {user?.name || "Sofia Carter"}
            </Text>
            <Text className="text-base text-gray-500">
              {user?.email || "sofia.carter@email.com"}
            </Text>
          </View>

          {/* Account Section */}
          <View className="mb-8">
            <Text className="text-lg font-bold text-black mb-4">Cuenta</Text>
            <View className="bg-white rounded-xl border border-gray-200 overflow-hidden">
              <TouchableOpacity className="flex-row items-center justify-between p-4 border-b border-gray-100">
                <Text className="text-base text-black">Editar Perfil</Text>
                <IconSymbol name="chevron.right" size={20} color="#9CA3AF" />
              </TouchableOpacity>
              <TouchableOpacity className="flex-row items-center justify-between p-4">
                <Text className="text-base text-black">Cambiar Contraseña</Text>
                <IconSymbol name="chevron.right" size={20} color="#9CA3AF" />
              </TouchableOpacity>
            </View>
          </View>

          {/* Progress Section */}
          <View className="mb-8">
            <Text className="text-lg font-bold text-black mb-4">Progreso</Text>
            <View className="bg-white rounded-xl border border-gray-200 p-4">
              {progressData.map((item, index) => (
                <View key={index} className="mb-4 last:mb-0">
                  <View className="flex-row items-center justify-between mb-2">
                    <Text className="text-base text-black">{item.subject}</Text>
                    <Text
                      className="text-base font-medium"
                      style={{ color: item.color }}
                    >
                      {item.progress}%
                    </Text>
                  </View>
                  <View className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <View
                      className="h-full rounded-full"
                      style={{
                        width: `${item.progress}%`,
                        backgroundColor: item.color,
                      }}
                    />
                  </View>
                </View>
              ))}
            </View>
          </View>

          {/* Additional Options */}
          <View className="mb-8">
            <View className="bg-white rounded-xl border border-gray-200 overflow-hidden">
              <TouchableOpacity className="flex-row items-center justify-between p-4 border-b border-gray-100">
                <Text className="text-base text-black">Configuración</Text>
                <IconSymbol name="chevron.right" size={20} color="#9CA3AF" />
              </TouchableOpacity>
              <TouchableOpacity className="flex-row items-center justify-between p-4 border-b border-gray-100">
                <Text className="text-base text-black">Ayuda y Soporte</Text>
                <IconSymbol name="chevron.right" size={20} color="#9CA3AF" />
              </TouchableOpacity>
              <TouchableOpacity className="flex-row items-center justify-between p-4">
                <Text className="text-base text-red-500">Cerrar Sesión</Text>
                <IconSymbol name="chevron.right" size={20} color="#EF4444" />
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </View>
    </>
  );
}
